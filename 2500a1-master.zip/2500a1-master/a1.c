#include <stdio.h>
#include <string.h>

int main(void) {
    int i = 0;
    int numWords = 0;
    int numLines = 0;
    int lineWordCount = 0;
    
    char currentLine[50];
    int wordsByLine[1001];
    
    printf("Enter the poem:\n");
    
    while(1) {
        fgets(currentLine, 50, stdin);
        
        if(currentLine[0] == '.' && strlen(currentLine) == 2) {//break if poem ends
            break;
        }
        
        for(int i = 0; i < strlen(currentLine); i++) {//word counting
            if(currentLine[i] == ' ') {
                lineWordCount++;
            }
        }
        lineWordCount++;//extra word in there homie
        
        wordsByLine[numLines] = lineWordCount;
        numWords += lineWordCount;
        lineWordCount = 0;
        numLines++;
    }
    
    printf("%d %s on %d %s\n", numWords, (numWords == 1) ? "word":"words", numLines, (numLines == 1) ? "line":"lines");
    for(int i = 0; i < numLines; i++) {
        printf("%d ", wordsByLine[i]);
    }
    printf("\n";
    
    return 0;
}
