#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main(void)
{
    int i = 0;
    int numLines = 0;
    char **poemArray = malloc(sizeof(char*)); //must use malloc for all of the strings within the array
    
    char currentLine[1000];
    
    printf("Enter the poem:\n");
    
    while(1) {
        fgets(currentLine, 1000, stdin);
        
        if(currentLine[0] == '.' && strlen(currentLine) == 2) {//break if poem ends
            break;
        }
        numLines++;
        poemArray = realloc(poemArray, sizeof(char*) * (numLines + 1));
        poemArray[numLines] = malloc(sizeof(char) * strlen(currentLine) + 1);
        strcpy(poemArray[numLines], currentLine);        
    }
    //try with numLines - 1 or +1 if this don't square    
    for(i = numLines; i > 0; i--) {
        printf("%s\n", poemArray[i]);
    }
    
    for(i = 0; i < numLines; i++) {
        free(poemArray[i]);
    }
    free(poemArray);
    
    return 0;
}
