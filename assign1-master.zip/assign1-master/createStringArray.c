#include <stdio.h>
#include <stdlib.h>

/*
Creates an array of strings; that is, an array of
pointers. Parameter number is the number of strings desired in the array.
*/
char **createStringArray(int number)
{
    char strArray = malloc(sizeof(*char) * number);
    
    return strArray;
}
