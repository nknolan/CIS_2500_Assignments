#include <stdio.h>
#include <stdlib.h>

void free2DArray(int *array)
{
    free(array);
}
