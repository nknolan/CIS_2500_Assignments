#include <stdio.h>
#include <stdlib.h>

/*
Frees memory allocated to strings, then frees the
memory allocated to the array of pointers.
*/

void freeStringArray(char **array, int number)
{
    int i = 0;
    for(i = 0; i < number; i++) {
        free(array[i]);
    }
    
    free(array);
}
