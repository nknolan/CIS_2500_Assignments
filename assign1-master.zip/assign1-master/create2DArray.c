#include <stdio.h>
#include <stdlib.h>

/*
For future personal reference:
The 1D array hosts two dimensions of data by multiplying row by max rows,
then adding columns. So in a 10x10 array, to get to 43 we go 4 x (10) + 3.
This means that the (10) needs to be saved somewhere, hence the global.
*/
int *create2DArray(int rows, int cols)
{
    extern int maxRows;
    int total = (rows * cols);
    
    int *myArray = (int *)malloc(sizeof(int) * total);
    maxRows = rows;//This information is key to organizing the array for later on
    
    return myArray;//a pointer to the dynamically allocated data structure
}
