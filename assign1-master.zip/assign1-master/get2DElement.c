#include <stdio.h>

/*
Uses the same logic as set element to locate 2D item.
*/
int get2DElement(int *array, int row, int col)
{
    extern int maxRows;
    //address = row x maxRows for row, then col for column
    return array[(row * maxRows) + col];
}
