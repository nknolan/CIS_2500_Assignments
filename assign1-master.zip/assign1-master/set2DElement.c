#include <stdio.h>

/*
Gets the number of rows from global, then uses it in the
formula row * num rows + column to get the correct address.
*/
void set2DElement(int *array, int row, int col, int value)
{
    
    extern int maxRows;
    int addr = (row * maxRows) + col;
    
    if(array[addr] == NULL) {
        array[(row * maxRows) + col] = value;//ONE HELL OF A HAIL MARY RIGHT HERE FELLAS
    }
}
