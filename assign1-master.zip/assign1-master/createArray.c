#include <stdio.h>
#include <stdlib.h>

/*
Creates a 2D int array dynamically, with each area of size
rows divided into cols.
*/

int **createArray(int rows, int cols)
{
    int i = 0;
    int **myArray = malloc(sizeof(*int) * rows);
    
    for(i = 0; i < rows; i++) {
        myArray[i] = malloc(sizeof(*myArray[i]) * cols);
    }
}
