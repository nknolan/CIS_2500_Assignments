#include <stdlib.h>

/*
Frees array memory, individual
subarrays first and then the
master array.
*/

void freeArray(int **array, int rows, int cols)
{
    int i = 0;
    
    //NB I have no idea if this works but it looks like it might.
    for(i = 0; i < rows; i++) {
        free(array[i];
    }
    
    free(array);
}
