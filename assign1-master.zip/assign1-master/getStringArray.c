#include <stdio.h>

/*
Returns the string from the array.
*/

char *getStringArray(char **array, int index)
{
    return array[index];
}
