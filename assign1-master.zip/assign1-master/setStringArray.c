#include <stdio.h>
#include <string.h>

/*
Sets one of the strings in the string array
to the user's desired string. TODO this only
works for strings that aren't being changed,
since it just uses the = operator.
*/

void setStringArray(char **array, int index, char *string)
{
    int len = strlen(string);
    int xlen = len++;//a little less fussy than using len + 1 in malloc for some reason
    array[index] = malloc(sizeof(char) * xlen);
    
    strncpy(array[index], string, len);
}
